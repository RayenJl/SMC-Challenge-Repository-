
window.onload = function () {
    fetch('stats.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error(data.error);
                return;
            }

            const stats = data.userStats;

            // Set the username
            document.getElementById("profileName").innerText = stats.username;

            // Set the stats
            document.getElementById("totalGames").innerText = `${stats.totalGames} Games Played`;  // Use template literal
            document.getElementById("averageMoves").innerText = `${stats.averageMoves} Moves/Game`;  // Use template literal

            // Set up chart for win rate
            const ctx = document.getElementById("winRateChart").getContext("2d");
            const winRate = stats.winRate || 0;

            const chartData = {
                labels: ["Wins", "Losses"],
                datasets: [{
                    data: [winRate, 100 - winRate],
                    backgroundColor: ["#C1A37D", "#F8F1E5"],
                    borderColor: "#4B3621",
                    borderWidth: 2,
                }]
            };

            const options = {
                responsive: false,
                plugins: {
                    legend: {
                        display: true,
                        position: "bottom",
                        labels: {
                            color: "#4B3621",
                        },
                    },
                },
            };

            new Chart(ctx, {
                type: "doughnut",
                data: chartData,
                options: options,
            });

            // Optionally, if you want to store username and profile info locally
            let user = JSON.parse(localStorage.getItem("loggedInUser")) || {
                username: stats.username,
                photo: "defaultprofile.png",
            };
            localStorage.setItem("loggedInUser", JSON.stringify(user));
            document.getElementById("profileImg").src = user.photo;
        })
        .catch(error => console.error('Error fetching user stats:', error));
};

function updateProfileImage(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = function () {
            let user = JSON.parse(localStorage.getItem("loggedInUser")) || {
                username: "Guest",
                photo: "defaultprofile.png",
            };
            user.photo = reader.result;
            localStorage.setItem("loggedInUser", JSON.stringify(user));
            document.getElementById("profileImg").src = reader.result;
        };
        reader.readAsDataURL(file);
    }
}

function logout() {
    localStorage.removeItem("loggedInUser");
    window.location.href = "login.html";
}
