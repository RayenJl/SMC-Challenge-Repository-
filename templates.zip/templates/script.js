// Handle Start Game button click
document.querySelector('.game-btn').addEventListener('click', function () {
  const selectedMode = document.querySelector('#game-mode').value;

  if (selectedMode) {
      window.location.href = selectedMode;
  } else {
      alert('Please select a game mode to continue!');
  }
});

// Function to dynamically update score
let playerScore = 0;
let botScore = 0;


function updateScore(playerWins, botWins) {
  playerScore = playerWins;
  botScore = botWins;
  document.querySelector('#score-container span').textContent = `${playerScore}-${botScore}`;
}
function startGame() {
  // Redirect to the player-vs-robot.html page
  window.location.href = "templates/index.html";
}

function redirectToStatistics() {
  // Replace with the URL of the statistics site
  window.location.href = "dashboard.html";
}

function showGraphics() {
  alert("Graphics panel will be displayed (add your logic here).");
  // Implement logic to show graphics here
}
// Add event listener for the red button
document.querySelector('#red-button').addEventListener('click', function () {
    const moveDisplay = document.querySelector('#move-display2');
  
    // Check if the move-display element exists before applying the class
    if (moveDisplay) {
        // Add the red-flash class to start the animation
        moveDisplay.classList.add('red-flash');
    
        // After 10 seconds, remove the red-flash class to reset the color
        setTimeout(() => {
            moveDisplay.classList.remove('red-flash');
        }, 8888); // 10 seconds
    } else {
        console.error("Move display element not found.");
    }
});
