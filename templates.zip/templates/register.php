<?php
// Include the database connection
require 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Check if passwords match
    if ($password !== $confirmPassword) {
        echo "<script>alert('Passwords do not match!'); window.location.href='register.html';</script>";
        exit;
    }

    // Check if the username already exists in the database
    $stmt = $conn->prepare("SELECT * FROM login WHERE name = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "<script>alert('Username is already taken.'); window.location.href='register.html';</script>";
        exit;
    }

    // Hash the password using bcrypt (or other secure hashing methods)
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Insert the new user into the database
    $stmt = $conn->prepare("INSERT INTO login (name, password) VALUES (:username, :password)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashedPassword);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! You can now log in.'); window.location.href='login.html';</script>";
        exit;
    } else {
        echo "<script>alert('Error during registration.'); window.location.href='register.html';</script>";
    }
}
?>

