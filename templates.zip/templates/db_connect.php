<?php
// Database connection details
$host = 'localhost'; // or '127.0.0.1'
$dbname = 'chessdb';
$username = 'root'; // Default username for WAMP/XAMPP
$password = ''; // Default password is empty for WAMP/XAMPP

try {
    // Create a new PDO instance
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // If connection fails, display an error message
    echo "Connection failed: " . $e->getMessage();
    exit;
}
?>
