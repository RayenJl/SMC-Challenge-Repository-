<?php
// Start the session to store user data
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root"; // replace with your MySQL username
$password = ""; // replace with your MySQL password
$dbname = "chessdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $loginUsername = $_POST['loginUsername'];
    $loginPassword = $_POST['loginPassword'];

    // Prevent SQL injection
    $loginUsername = $conn->real_escape_string($loginUsername);
    $loginPassword = $conn->real_escape_string($loginPassword);

    // Check if the user exists in the database
    $sql = "SELECT * FROM login WHERE name = '$loginUsername'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User found, verify the password
        $user = $result->fetch_assoc();
        if (password_verify($loginPassword, $user['password'])) {
            // Password is correct, create session and redirect
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['name'];
            header("Location: interface.html");
            exit();
        } else {
            // Password is incorrect, send error to JS
            echo "<script>document.getElementById('loginError').textContent = 'Invalid username or password.';</script>";
        }
    } else {
        // User not found, send error to JS
        echo "<script>document.getElementById('loginError').textContent = 'Invalid username or password.';</script>";
    }
}

$conn->close();
?>
