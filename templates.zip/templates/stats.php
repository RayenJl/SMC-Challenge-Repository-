<?php
// Database credentials
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "chessdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'User not logged in']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user stats and username from the database
$sql = "SELECT l.name, s.total_games, s.winrate, s.average_moves 
        FROM login l 
        JOIN stat s ON l.id = s.user_id 
        WHERE l.id = $user_id LIMIT 1";
$result = $conn->query($sql);

// Check if user stats are found
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $userStats = [
        'username' => $row['name'],
        'totalGames' => $row['total_games'],
        'winRate' => $row['winrate'],
        'averageMoves' => $row['average_moves'],
    ];
} else {
    $userStats = [
        'username' => 'Guest',
        'totalGames' => 0,
        'winRate' => 0,
        'averageMoves' => 0,
    ];
}

// Close the database connection
$conn->close();

// Return the data as a JSON response
echo json_encode([
    'userStats' => $userStats
]);
?>
